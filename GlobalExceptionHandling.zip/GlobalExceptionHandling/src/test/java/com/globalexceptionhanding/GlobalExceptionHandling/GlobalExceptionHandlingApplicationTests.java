package com.globalexceptionhanding.GlobalExceptionHandling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalExceptionHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
